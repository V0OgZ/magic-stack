# Heroes of Time — Objets & pouvoirs

- **Briseur de Voile** : traverse CF/OPC pendant X secondes/cases.
- **Lanterne de Vince** : vision à travers CF (dévoile furtifs).
- **Ampoule d’Éther** : +A instantané (sprint).
- **Sabliers Jumeaux** : crée un clone J-Δ qui accélère pour rattraper.
- **Balise d’Ancrage** : retour sécurisé au snapshot.
- **Miroir de Déphasage** : furtivité courte (Φ sensible).
- **Corde de Causalité** : recule un ennemi d’un pas (micro-retour).
- **Sceau d’Anna** : résistance partielle à la décroissance.
- **Spikes temporaux** : pièges anti-rush.
