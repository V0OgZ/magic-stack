# Heroes of Time — Chasse temporelle (J1→J25)

## Joueurs & loadouts
- **Ventus** (speed/harass): Bottes de Chronos, Briseur de Voile, Ampoule d’Éther.
- **Axis** (voyage/clone): Sabliers Jumeaux, Balise d’Ancrage, Portail de Poche.
- **Terra** (bâtisseur/zone): Sceau d’Anna, Lanterne de Vince, Spikes temporaux.
- **Nyx** (furtif/sabotage): Miroir de Déphasage, Corde de Causalité, Boussole d’Ombre.

## Phases J1→J25 (A→F)
(voir chronologie détaillée et schémas dans les versions précédentes — conservées ici en synthèse)
