# Heroes of Time — README de navigation (gros index)

Bienvenue ! Ce README sert de **table des matières intelligente** pour naviguer rapidement dans tous les fichiers du pack.
Il propose : un **parcours conseillé**, des **sections par rôle**, une **carte des fichiers**, et des **liens directs** vers les ZIP.

---

## 🧭 Parcours conseillé (20–30 min)

1. **Pitch & bases** → [01_bases_concepts.md](01_bases_concepts.md)
2. **Règles moteur** → [02_regles_moteur.md](02_regles_moteur.md)
3. **Ombre portée & brouillard** → [03_ombre_brouillard.md](03_ombre_brouillard.md)
4. **Résolutions (Collapse/TCG/Auto)** → [04_systemes_resolution.md](04_systemes_resolution.md)
5. **Identité Ψ & énergie complexe** → [05_identite_energie_complexe.md](05_identite_energie_complexe.md)
6. **Interférences → gameplay** → [06_interferences_gameplay.md](06_interferences_gameplay.md)
7. **Objets & pouvoirs** → [07_objets_pouvoirs.md](07_objets_pouvoirs.md)
8. **Schémas ASCII (vision globale)** → [10_schemas_ascii_tous.md](10_schemas_ascii_tous.md)
9. **Scénario intégral J1→J25** → [09_chasse_temporelle_J25.md](09_chasse_temporelle_J25.md)
10. **Tests & cas limites** → [14_etudes_de_cas_tests.md](14_etudes_de_cas_tests.md)

Pour tout avoir en un fichier : **[MASTER.md](MASTER.md)**

---

## 👥 Par rôle

### Joueurs
- **Présentation simple** → [11_doc_joueur.md](11_doc_joueur.md)
- **Objets & pouvoirs** → [07_objets_pouvoirs.md](07_objets_pouvoirs.md)
- **Scénario J1→J25** → [09_chasse_temporelle_J25.md](09_chasse_temporelle_J25.md)

### Dev Front‑End
- **États/UX/événements** → [12_doc_front.md](12_doc_front.md)
- **Guide débutant (vertical slice)** → [README_FRONT_DEBUTANT.md](README_FRONT_DEBUTANT.md)
- **Schémas & effets** → [10_schemas_ascii_tous.md](10_schemas_ascii_tous.md)
- **Interférences (indicateurs UI)** → [06_interferences_gameplay.md](06_interferences_gameplay.md)

### Dev Back‑End
- **Horloges, énergie, dette** → [02_regles_moteur.md](02_regles_moteur.md)
- **Ψ/Φ & Interférences (formules)** → [05_identite_energie_complexe.md](05_identite_energie_complexe.md)
- **Déclencheurs Collapse/TCG/Auto** → [04_systemes_resolution.md](04_systemes_resolution.md)
- **Modèle graphe & orchestration** → [25_etat_monde_graphe_orchestration.md](25_etat_monde_graphe_orchestration.md)
- **Théorie 26D (analogie)** → [26_topologie_ontologie_vs_theorie_du_tout.md](26_topologie_ontologie_vs_theorie_du_tout.md)
- **Cas limites & tests** → [14_etudes_de_cas_tests.md](14_etudes_de_cas_tests.md), [16_scenarios_cas_tordus_paradoxes.md](16_scenarios_cas_tordus_paradoxes.md), [17_tests_fonctionnels_unitaires.md](17_tests_fonctionnels_unitaires.md)

### Multijoueur
- **Playbooks** → [19_playbooks_multijoueur.md](19_playbooks_multijoueur.md)
- **Matrice résultats** → [20_matrice_resultats_multi.md](20_matrice_resultats_multi.md)
- **Diagrammes** → [21_diagrammes_spatio_temporels_multi.md](21_diagrammes_spatio_temporels_multi.md)
- **Charge & concurrence** → [22_protocoles_charge_concurrence.md](22_protocoles_charge_concurrence.md)
- **Sécurité & anti‑abus** → [23_securite_anti_abus.md](23_securite_anti_abus.md)
- **Scripts sandbox (pseudo)** → [24_scripts_sandbox_pseudo.md](24_scripts_sandbox_pseudo.md)

### Synthèses
- **Conclusion méta/philo** → [15_conclusion_meta.md](15_conclusion_meta.md)
- **Final words** → [28_final_words.md](28_final_words.md)
- **Dialogue WTF** → [27_wtf_is_this_game_dialogue.md](27_wtf_is_this_game_dialogue.md)
- **MASTER** → [MASTER.md](MASTER.md) — document intégral (concat automatique).

---

## 📦 Packs & téléchargements rapides

- **Pack “tout le corpus”** → [Heroes_of_Time_MD_COMPLETE.zip](Heroes_of_Time_MD_COMPLETE.zip)
- **Pack “edge & tests”** → [Heroes_of_Time_EDGE_TESTS.zip](Heroes_of_Time_EDGE_TESTS.zip)
- **Pack “multiplayer”** → [Heroes_of_Time_MULTIPLAYER_PACK.zip](Heroes_of_Time_MULTIPLAYER_PACK.zip)

---

## 🧩 Glossaire ultra‑court

- **A** : énergie réelle (coût actions) · **Φ** : phase/cohérence (imag.).  
- **|ψ⟩** : identité d’une entité à travers ses incarnations.  
- **|I|** : qualité d’interférence entre incarnations (détermine effets).  
- **OPC** : ombre portée causale (potentiel) · **CF** : brouillard de causalité (incertitude).  
- **V/An/O** : Vince (perçage), Anna (décroissance), Overload (nettoyage).
