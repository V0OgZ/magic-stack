# Heroes of Time — Systèmes de résolution

## 1) Collapse probabiliste
- Utilisé si impact faible / écart de niveau fort.
- Résolution rapide, pas d’UI cartes.

## 2) Combat TCG
- Impact élevé / niveaux proches.
- Manuel par défaut ; **auto** si opt-in des deux.
- **AFK > 60s** ⇒ IA prend le relais (niveau IA ≤ 3).

## 3) Régulateurs
- Déclenchés en cas d’abus : tortue, surcharge, soft-lock.
