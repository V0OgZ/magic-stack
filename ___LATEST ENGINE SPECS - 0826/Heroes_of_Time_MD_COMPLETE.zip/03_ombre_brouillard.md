# Heroes of Time — Ombre portée & Brouillard

## Ombre portée causale (OPC)
- Potentiel d’atteinte si on exploite immédiatement vitesse + objets + chemins.
- Se **réduit** si on laisse filer le temps (dérive) sans agir.

## Brouillard de causalité (CF)
- Incertitude perçue par les autres sur une zone.
- **Vince** peut percer CF ; **Anna** peut compresser (en rongeant l’économie).

## Protéger le fun
- Empêcher le “soft-lock” : pas de blocage total durable.
- Les objets “brise-voile” la traversent à fenêtre limitée.
