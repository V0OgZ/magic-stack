# Heroes of Time — Sécurité & anti‑abus

- **Rollback dupe** : marquage causal + `causal_guard`
- **ψ spoof** : signatures non forgeables pour `psi_id`
- **Clone amplification** : cap `Σ|ψ|^2` + Overload
- **Portal camping** : fair window + coût occupation
- **Edge desync** : horloge serveur autoritaire (`t_w`)
- **Seed determinism** : RNG seedé par `match_id + tick + trace_hash`
- **Stealth grief** : visibilité minimale + perçage Vince fenêtré
