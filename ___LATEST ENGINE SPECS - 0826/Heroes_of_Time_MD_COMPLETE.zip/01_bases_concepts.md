# Heroes of Time — Bases & concepts

- **Jour caché** : équivalent de “tour” invisible piloté par l’énergie A (PA).
- **Énergie A (réelle)** : ce que coûtent mouvements/sorts/interactions.
- **Phase Φ (imaginaire)** : cohérence temporelle pour clones, superpositions & fusions.
- **Identité `|ψ⟩`** : vecteur normalisé (2–4D) représentant l’entité à travers ses incarnations.
- **Ombre portée causale** : zone spatio-temporelle potentielle.
- **Brouillard de causalité** : incertitude visible côté adversaire.
