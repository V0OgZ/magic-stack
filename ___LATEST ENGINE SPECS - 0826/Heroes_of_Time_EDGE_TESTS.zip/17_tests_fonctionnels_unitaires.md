# Tests fonctionnels & unitaires

## Unitaires
- `compute_interference`, `split_coherence`, `tick_decoherence`.
- `regulator_scan`, `attempt_fusion`, `reachable_OPC`.

## Fonctionnels
- F01 torus wrap, F02 rollback idempotent, F03 overload, F04 AFK takeover, F05 tempête CF.

## Property-based
- P01 conservation Σ|ψ|², P02 déterminisme trace, P03 no-deadlock CF/stabilisation.
