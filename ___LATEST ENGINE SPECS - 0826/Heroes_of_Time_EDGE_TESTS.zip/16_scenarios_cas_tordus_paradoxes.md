# Scénarios tordus & paradoxes (stress moteur)

- **Boucle de re-phase**: tenter `⤺` successifs — attendu: bruit Φ, cooldowns, régulateurs.
- **Finales simultanées**: deux victoires même tick — attendu: arbitre + trace_hash.
- **Portail ping-pong**: wrap+portail — attendu: coût cumulé, pas de “free TP”.
- **Clone croisé multi**: ψ incompatibles n’interfèrent pas (0 buff croisé).
