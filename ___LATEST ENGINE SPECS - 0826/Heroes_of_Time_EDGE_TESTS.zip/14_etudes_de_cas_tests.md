# Heroes of Time — Études de cas & tests d’acceptation

- [ ] **AFK 10 min** : OPC se contracte ; Anna/Vince si blocage.
- [ ] **Dépense A_max rapide** : passage jour+1 ; régén OK.
- [ ] **Dette** : `Debt_A` monte ; malus ; `t_e` accéléré.
- [ ] **Duel lvl 1 vs 18** : **collapse** direct (pas TCG).
- [ ] **TCG auto** quand opt-in des deux ; **AFK→IA** après 60 s.
- [ ] **Clone rattrapage** : `|I|` → effet (carte/buff/dissipation).
- [ ] **Briseur/Lanterne** : fenêtre on/off correcte.
- [ ] **Overload** : collapse auto si stack excessif ; pas de faux positifs.
- [ ] **Hold Noyau** : compte jours cachés (pas temps IRL).
- [ ] **Stabilisation** : Δ↑ → régulations ; Φ décroît (λ↑).
