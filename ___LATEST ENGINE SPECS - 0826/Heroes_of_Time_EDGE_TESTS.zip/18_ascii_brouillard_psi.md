# ASCII — brouillard & propagation Ψ

```
CF: █ inconnu, ▒ semi, . clair
Ψ:  ● main, ○ clone

y
8 | █ █ █ ▒ ▒ ▒
7 | █ ● → → . .
6 | █   ○ → . .
    +----------→ x
```
